'use strict';

angular.module('myApp.userController', [])
        .controller('userController', ['$scope','$rootScope', '$timeout','$http', '$interval', '$q' ,'userService','FlashService',function ($scope,$rootScope,$timeout, $http, $interval, $q,userService,FlashService) {
$scope.userList=[];
  $scope.userId=null;
  $scope.functionality="";
  $scope.myJsonString=[];
  $scope.business={};
  $scope.workPackagemultiobj={};
  $scope.workPackagemultiselect=[];
  $scope.workPackageList=[];
  $scope.businessselect=[];
  $scope.example14model = [];
  $scope.list=[];
  $scope.example6model=[];
 // $scope.example6data = [ { id: 1, label: 'David' }, { id: 2, label: 'Jhon' }, { id: 3, label: 'Danny' } ];
  $scope.example6settings = {
		 /* scrollableHeight: '300px',
	      scrollable: true,
	      enableSearch: true  */
  };
  $scope.customFilter = '';
 
  
  $scope.loclist =[];

  $scope.example2settings = {
      displayProp: 'id'
  };
  var headers = {
		    'Auth_Token':$rootScope.globals.userDTO.token
		  }

	var config={
		  headers:headers
	}
var phoneno = /^\d{10}$/;  
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
  $scope.maxDate = new Date();
  $scope.statuses = [{
      "statusId" : "M" ,
      "statusName" : "Male"
    },
    {
      "statusId" : "F" ,
      "statusName" : "Female"
    }];
$scope.statusId = "M";
$scope.usertypes = [{
    "typeId" : "Internal" ,
    "typeName" : "Internal"
  },
  {
    "typeId" : "External" ,
    "typeName" : "External"
  }];
$scope.userType = "Internal";
$scope.inputType = 'password';

// Hide & show password function
$scope.hideShowPassword = function(){
  if ($scope.inputType == 'password')
    $scope.inputType = 'text';
  else
    $scope.inputType = 'password';
};

  this.myDate = new Date();

  this.isOpen = false;
	$scope.userImage = "assets/global/img/profile.jpg";
  var fakeI18n = function( title ){
	    var deferred = $q.defer();
	    $interval( function() {
	      deferred.resolve( 'col: ' + title );
	    }, 1000, 1);
	    return deferred.promise;
	  };
	  $scope.gridOptions = {
	  };

            $scope.gridOptions = {
              paginationPageSizes: [25, 50, 75],
              paginationPageSize: 25,
              exporterMenuCsv: true,
              enableGridMenu: true,
              enableFiltering: true,
              gridMenuTitleFilter: fakeI18n,
              columnDefs: [
                { name: 'username', displayName:"User Name" },
                {name:'roleName',displayName:"Role Name" },
                { name: 'fullName', displayName:"Full Name" },
                {name:'dob',displayName:"Date of Birth" },
                { name: 'userType', displayName:"User Type" },
                {name:'gender',displayName:"Gender" },
                { name: 'primaryEmail', displayName:"Primary Email Id" },
                {name:'primaryMobileNo',displayName:"Primary Mobile Number" },
                { name: 'country', displayName:"Country" },
                {name:'state',displayName:"State" },
                {name:'userId',displayName:"Action",cellTemplate: '<div  class="ui-grid-cell-contents" >  <div class="col-sm-12 lookup-action"> \
                     &nbsp; <i class="fa fa-pencil-square-o" ng-click="grid.appScope.editUser(COL_FIELD)" style="cursor:pointer" ></i> \
                     &nbsp; <i class="fa fa-eye" ng-click="grid.appScope.viewUser(COL_FIELD)"  style="cursor:pointer"></i> \
                 </div></div> ',enableFiltering: false,width:100}
              ],

              onRegisterApi: function( gridApi ){
                $scope.gridApi = gridApi;

                // interval of zero just to allow the directive to have initialized


                gridApi.core.on.columnVisibilityChanged( $scope, function( changedColumn ){
                  $scope.columnChanged = { name: changedColumn.colDef.name, visible: changedColumn.colDef.visible };
                });
              }
            };

          /*  $http.get('http://ui-grid.info/data/100.json')
              .success(function(data) {
                $scope.gridOptions.data = data;
              });*/
      loadAll();
      function loadAll(){
    	 
      
      $scope.list=[];
     
       
        userService.getAllUsers(config).then(function (data) {

             $scope.userList= data.data.objects;

             for(var i=0;i<$scope.userList.length;i++)
             {

                  $scope.userList[i].action="";

             }
               $scope.gridOptions.data =$scope.userList;
          });
          userService.getAllRoles(config).then(function (data) {

               $scope.roleList= data.data.objects;
            });
       
        console.log("----------"+$scope.userList);
      }

      $scope.createUser = function () {
    	  $scope.functionality="Save";
        $scope.headername = "Create User";
        $scope.profileImage="";
        $scope.username="";
        $scope.password="";
        $scope.roleId ="";
        $scope.fullName="";
        $scope.dob="";
        $scope.userType="";
        $scope.gender="";
        $scope.identityNumber="";
        $scope.primaryEmail="";
        $scope.alternateEmail="";
        $scope.primaryMobileNo="";
        $scope.alternateMobileNo="";
        $scope.country="";
        $scope.state="";
        $scope.city="";
        $scope.zipcode="";
        $scope.address="";
        $scope.orgId=null;
       


      //  $scope.category={};
      $scope.userId=null;

        $rootScope.isTrascError = false;
        $scope.isView = false;
        $('div').removeClass('has-error edited').removeClass('has-error');
        $('input').removeClass('form-control edited').addClass('form-control');
        $('textarea').removeClass('form-control edited').addClass('form-control');
        $('select').removeClass('form-control edited').addClass('form-control');
        $('#user-model').modal('show');
      }
      $scope.editUser=function(value)
      	{
    	  $scope.functionality="Update";
    	  $scope.isView = false;
        	$scope.headername = "Edit User Profile";
          $scope.profileImage="";
          $scope.username="";
          $scope.password="";
          $scope.roleId ="";
          $scope.fullName="";
          $scope.dob="";
          $scope.userType="";
          $scope.gender="";
          $scope.identityNumber="";
          $scope.primaryEmail="";
          $scope.alternateEmail="";
          $scope.primaryMobileNo="";
          $scope.alternateMobileNo="";
          $scope.country="";
          $scope.state="";
          $scope.city="";
          $scope.zipcode="";
          $scope.address="";
         
          $scope.userId=value;
          

          for(var i=0;i<$scope.userList.length;i++)
          {
              if ($scope.userList[i].userId==value)
               {

                $scope.userId=$scope.userList[i].userId;
                 $scope.username=$scope.userList[i].username;
                 $scope.password=window.atob($scope.userList[i].password);
                 $scope.roleId =$scope.userList[i].roleId;
                 $scope.fullName=$scope.userList[i].fullName;
                 $scope.dob=$scope.userList[i].dob;
                 $scope.userType=$scope.userList[i].userType;
                
             
                 $scope.gender=$scope.userList[i].gender;

                 $scope.identityNumber=$scope.userList[i].identityNumber;
                 $scope.primaryEmail=$scope.userList[i].primaryEmail;
                 $scope.alternateEmail=$scope.userList[i].alternateEmail;
                 $scope.primaryMobileNo=$scope.userList[i].primaryMobileNo;
                 $scope.alternateMobileNo=$scope.userList[i].alternateMobileNo;
                 $scope.country=$scope.userList[i].country;
                 $scope.state=$scope.userList[i].state;
                 $scope.city=$scope.userList[i].city;
                 $scope.zipcode=$scope.userList[i].zipcode;
                 $scope.address=$scope.userList[i].address;
            
               

              }
          }
          $rootScope.isTrascError = false;
          $('div').removeClass('has-error edited');
          $('input').removeClass('form-control').addClass('form-control edited');
          $('textarea').removeClass('form-control').addClass('form-control edited');
          $('select').removeClass('form-control').addClass('form-control edited');
          $('#user-model').modal('show');
      				}
        $scope.viewUser=function(value)
                {

                            $scope.isView = true;
                          	$scope.headername = "View User Profile";
                            $scope.profileImage="";
                            $scope.username="";
                            $scope.password="";
                            $scope.roleId ="";
                            $scope.fullName="";
                            $scope.dob="";
                            $scope.userType="";
                            $scope.gender="";
                            $scope.identityNumber="";
                            $scope.primaryEmail="";
                            $scope.alternateEmail="";
                            $scope.primaryMobileNo="";
                            $scope.alternateMobileNo="";
                            $scope.country="";
                            $scope.state="";
                            $scope.city="";
                            $scope.zipcode="";
                            $scope.address="";
                          
                            for(var i=0;i<$scope.userList.length;i++)
                            {
                                if ($scope.userList[i].userId==value)
                                 {

                                  $scope.userId=$scope.userList[i].userId;
                                   $scope.username=$scope.userList[i].username;
                                   $scope.password=window.atob($scope.userList[i].password);
                                   $scope.roleId =$scope.userList[i].roleId;
                                   $scope.fullName=$scope.userList[i].fullName;
                                   $scope.dob=$scope.userList[i].dob;
                                   $scope.userType=$scope.userList[i].userType;
                                    $scope.profileImage=$scope.userList[i].image;
                               
                                   $scope.gender=$scope.userList[i].gender;
       
                                   $scope.identityNumber=$scope.userList[i].identityNumber;
                                   $scope.primaryEmail=$scope.userList[i].primaryEmail;
                                   $scope.alternateEmail=$scope.userList[i].alternateEmail;
                                   $scope.primaryMobileNo=$scope.userList[i].primaryMobileNo;
                                   $scope.alternateMobileNo=$scope.userList[i].alternateMobileNo;
                                   $scope.country=$scope.userList[i].country;
                                   $scope.state=$scope.userList[i].state;
                                   $scope.city=$scope.userList[i].city;
                                   $scope.zipcode=$scope.userList[i].zipcode;
                                   $scope.address=$scope.userList[i].address;
                             
                                
                               
                                  

                                }
                            }




                  $rootScope.isTrascError = false;
                  $('div').removeClass('has-error edited');
                  $('input').removeClass('form-control').addClass('form-control edited');
                  $('textarea').removeClass('form-control').addClass('form-control edited');
                  $('select').removeClass('form-control').addClass('form-control edited');
                  $('#user-model').modal('show');
                      }


                      $scope.saveUser = function (username,password,roleId,fullName,dob,userType,gender,identityNumber,primaryEmail,alternateEmail,primaryMobileNo,alternateMobileNo,country,state,city,zipcode,address) {

                        var user={};
                      
                        var userId=$scope.userId;
                       
                     
                        user.username=username;
 	                      user.password=window.btoa(password);
 	                      user.roleId=roleId;
 	                      user.fullName=fullName;
 	                 
 	                   
 	                  if(dob ==null || dob==undefined || dob=="")
	{
 	   user.dob=null;                 
	}
else
	{
	  user.dob=dob;
	}
if(gender ==null ||gender == undefined || gender =="")
	{
    user.gender="M";
	}
else
	{
	 user.gender=gender;
	}

 	                      user.userType=userType;
                     
                        user.identityNumber=identityNumber;
                     	  user.primaryEmail=primaryEmail;
                     	  user.alternateEmail=alternateEmail;
                     	  user.primaryMobileNo=primaryMobileNo;
                     	  user.alternateMobileNo=alternateMobileNo;

                     	  user.country=country;
                     	  user.state=state;
                     	  user.city=city;
                     	  user.zipcode=zipcode;
                     	  user.address=address;

             
               
   
if(primaryMobileNo ==undefined)
	{
	primaryMobileNo="";
	}
if(alternateMobileNo==undefined)
	{
	alternateMobileNo="";
	}



                        $scope.continuesave = true;

                            if (!username || username==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter User Name");
                                 $scope.continuesave = false;
                             } else if (!password || password==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter Password");
                                 $scope.continuesave = false;
                             } else if (!roleId || roleId==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Select Role");
                                 $scope.continuesave = false;
                             }else if (primaryMobileNo.length>10 || primaryMobileNo.length<10 && primaryMobileNo!="" ) {
                           
                            		     
                            		    	  $rootScope.isTrascError = true;
                                              FlashService.Error("Please Enter correct Primary Mobile Number");
                                              $scope.continuesave = false;
                            		   
                                
                             }
                          
                            
                             else if (alternateMobileNo.length>10 || alternateMobileNo.length<10 && alternateMobileNo!="") {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter correct Alternate Mobile Number");
                                 $scope.continuesave = false;
                             }
                          
                              else if (!fullName || fullName==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter Fullname");
                                 $scope.continuesave = false;
                             }
                             else if (!userType || userType==undefined) {

                                $rootScope.isTrascError = true;
                                FlashService.Error("Please Select User Type");
                                $scope.continuesave = false;
                            }
                      
                           
                           
                     
                            
                          

                              else {
                                 $scope.continuesave = true;
                                 $rootScope.isTrascError = false;
                             }
                             if(primaryMobileNo.length ==10)
                       	 {
                       	 
                        	 if(primaryMobileNo.match(phoneno))  
                        		        {  
                        		    
                        		        }  
                        		      else  
                        		        {  
                        		    	  $rootScope.isTrascError = true;
                                          FlashService.Error("Please Enter correct Primary Mobile Number");
                                          $scope.continuesave = false;
                        		        }  
                       	 }
                             if(alternateMobileNo.length ==10)
                        	 {
                        	
                         	 if(alternateMobileNo.match(phoneno))  
                         		        {  
                         		   
                         		        }  
                         		      else  
                         		        {  
                         		    	  $rootScope.isTrascError = true;
                                           FlashService.Error("Please Enter correct Alternate Mobile Number");
                                           $scope.continuesave = false;
                         		        }  
                        	 }
                          
                             if(primaryEmail !="" )
                            	 {
                            
                            	
                            	 if(primaryEmail.match(mailformat))  
                            	 {  
                            	
                            	 }  
                            	 else  
                            	 {  
                            		  $rootScope.isTrascError = true;
                                      FlashService.Error("Please Enter correct Primary Email Id");
                                      $scope.continuesave = false;
                            	 }  
                            	 }
                             if( alternateEmail !="" )
                        	 {
                              
                        	 if(alternateEmail.match(mailformat))  
                        	 {  
                        	
                        	 }  
                        	 else  
                        	 {  
                        		  $rootScope.isTrascError = true;
                                  FlashService.Error("Please Enter correct Alternate Email Id");
                                  $scope.continuesave = false;
                        	 }  
                        	 }
                            if ($scope.continuesave) {

                                 if (!userId) {
                                	user.createdBy= $rootScope.globals.userDTO.userId;
                                     userService
                                             .saveUser(user)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 201) {

                                                             $('#user-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 } else {

                                   user.userId=userId;
                               	user.updatedBy= $rootScope.globals.userDTO.userId;
                                    userService
                                             .updateUser(user)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 200) {
                                                             $('#user-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 }
                             }
                      }

                
                  


            }]);
