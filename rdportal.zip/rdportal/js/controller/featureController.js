'use strict';

angular.module('myApp.featureController', [])
        .controller('featureController', ['$scope','$rootScope', '$http', '$interval', '$q' ,'featureService','FlashService',function ($scope,$rootScope, $http, $interval, $q,superorgService,FlashService) {
$scope.featureList=[];
  $scope.featureId=null;
  var headers = {
		    'Auth_Token':$rootScope.globals.userDTO.token
		  }

	var config={
		  headers:headers
	}
  var fakeI18n = function( title ){
	    var deferred = $q.defer();
	    $interval( function() {
	      deferred.resolve( 'col: ' + title );
	    }, 1000, 1);
	    return deferred.promise;
	  };
	  $scope.gridOptions = {
	  };

            $scope.gridOptions = {
              paginationPageSizes: [25, 50, 75],
              paginationPageSize: 25,
              exporterMenuCsv: true,
              enableGridMenu: true,
              enableFiltering: true,
              gridMenuTitleFilter: fakeI18n,
              columnDefs: [
                { name: 'featureName', displayName:"Feature Name" },
                {name:'featureDesc',displayName:"Feature Description" },
                {name:'featureId',displayName:"Action",cellTemplate: '<div  class="ui-grid-cell-contents" >  <div class="col-sm-12 lookup-action"> \
                     &nbsp; <i class="fa fa-pencil-square-o" ng-click="grid.appScope.editFeature(COL_FIELD)" style="cursor:pointer" ></i> \
                     &nbsp; <i class="fa fa-eye" ng-click="grid.appScope.viewFeature(COL_FIELD)"  style="cursor:pointer"></i> \
                 </div></div> ',enableFiltering: false,width:100}
              ],

              onRegisterApi: function( gridApi ){
                $scope.gridApi = gridApi;

                // interval of zero just to allow the directive to have initialized


                gridApi.core.on.columnVisibilityChanged( $scope, function( changedColumn ){
                  $scope.columnChanged = { name: changedColumn.colDef.name, visible: changedColumn.colDef.visible };
                });
              }
            };

          /*  $http.get('http://ui-grid.info/data/100.json')
              .success(function(data) {
                $scope.gridOptions.data = data;
              });*/
      loadAll();
      function loadAll(){

      

        featureService.getAllFeature(config).then(function (data) {
             $scope.superorgList= data;

             for(var i=0;i<$scope.featureList.length;i++)
             {
                  $scope.featureList[i].action="";
             }
               $scope.gridOptions.data =$scope.featureList;
          });
        console.log("----------"+$scope.featureList);
      }

     $scope.createfeature = function () {
        alert("in this");
        $scope.headername = "Create Feature";
        $scope.name ="";
        $scope.description="";
        alert("out");
      //  $scope.category={};
      $scope.featureId=null;

        $rootScope.isTrascError = false;
        $scope.isView = false;
        $('div').removeClass('has-error edited').removeClass('has-error');
        $('input').removeClass('form-control edited').addClass('form-control');
        $('textarea').removeClass('form-control edited').addClass('form-control');
        $('select').removeClass('form-control edited').addClass('form-control');
        $('#feature-model').modal('show');
      }
     $scope.editFeature=function(value)
      	{
          alert("edit");
          $scope.isView = false;
        	$scope.headername = "Edit Feature";
          $scope.name ="";
          $scope.description="";
          alert($scope.featureList.length);
          for(var i=0;i<$scope.featureList.length;i++)
          {
              if ($scope.featureList[i].featureId==value)
               {

                $scope.name=$scope.featureList[i].featureName;
                $scope.description=$scope.featureList[i].featureDesc;
                $scope.featureId=$scope.featureList[i].featureId;

              }
          }
          $rootScope.isTrascError = false;
          $('div').removeClass('has-error edited');
          $('input').removeClass('form-control').addClass('form-control edited');
          $('textarea').removeClass('form-control').addClass('form-control edited');
          $('select').removeClass('form-control').addClass('form-control edited');
          $('#feature-model').modal('show');
      				}
        $scope.viewFeature=function(value)
                {
                  $scope.featureId=null;
                  $scope.name="";
                  $scope.description="";
                  $scope.headername = "View Feature";
                  $scope.isView = true;
                  for(var i=0;i<$scope.featureList.length;i++)
                  {
                      if ($scope.featureList[i].featureId==value)
                      {
                        $scope.name=$scope.featureList[i].featureName;
                        $scope.description=$scope.featureList[i].featureDes;

                      }
                  }
                  $rootScope.isTrascError = false;
                  $('div').removeClass('has-error edited');
                  $('input').removeClass('form-control').addClass('form-control edited');
                  $('textarea').removeClass('form-control').addClass('form-control edited');
                  $('select').removeClass('form-control').addClass('form-control edited');
                  $('#feature-model').modal('show');
                      }

                      $scope.savefeature = function (featurename,featuredesc) {
                        var feature={};
                        var featureId=$scope.superOrganizationId;
                        feature.featureName = featurename;
                         feature.featureDes = featuredesc;

                        $scope.continuesave = true;
                            if (!featurename || featurename==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter Feature Name");
                                 $scope.continuesave = false;
                             } else if (!featuredesc || featuredesc==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter Feature Description");
                                 $scope.continuesave = false;
                             } else {
                                 $scope.continuesave = true;
                                 $rootScope.isTrascError = false;
                             }

                            if ($scope.continuesave) {

                                 if (!featureId) {

                                     featureService
                                             .saveFeature(feature)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 201) {

                                                             $('#feature-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 } else {
                                   alert("in update");
                                   feature.featureId=featureId;
                                    featureService
                                             .updateFeature(feature)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 200) {
                                                             $('#feature-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 }
                             }
                      }


            }]);
