'use strict';

angular.module('myApp.roleController', [])
        .controller('RoleCtrl', ['$scope','$rootScope', '$http', '$interval', '$q' ,'roleService','FlashService','$timeout',function ($scope,$rootScope, $http, $interval, $q,roleService,FlashService,$timeout) {
$scope.roleList=[];
$scope.availableFeatures=[];
$scope.includedFeatures = [];
$scope.selectedFeatures = [];
$scope.existingFeatures = [];
$scope.totalavailableFeatures = [];
  $scope.roleId=null;
  $scope.iseditable=true;
  $scope.functionality="";
  var headers = {
		    'Auth_Token':$rootScope.globals.userDTO.token
		  }

	var config={
		  headers:headers
	}
  var fakeI18n = function( title ){
	    var deferred = $q.defer();
	    $interval( function() {
	      deferred.resolve( 'col: ' + title );
	    }, 1000, 1);
	    return deferred.promise;
	  };
	  $scope.gridOptions = {
	  };

            $scope.gridOptions = {
              paginationPageSizes: [25, 50, 75],
              paginationPageSize: 25,
              exporterMenuCsv: true,
              enableGridMenu: true,
              enableFiltering: true,
              gridMenuTitleFilter: fakeI18n,
              columnDefs: [
                { name: 'roleName', displayName:"Role Name" },
                {name:'description',displayName:"Role Description" },
                {name:'roleId',displayName:"Action",cellTemplate: '<div  class="ui-grid-cell-contents" >  <div class="col-sm-12 lookup-action"> \
                     &nbsp; <i class="fa fa-pencil-square-o" ng-click="grid.appScope.editrole(COL_FIELD)" style="cursor:pointer" ></i> \
                     &nbsp; <i class="fa fa-eye" ng-click="grid.appScope.viewrole(COL_FIELD)"  style="cursor:pointer"></i> \
                 </div></div> ',enableFiltering: false,width:100}
              ],

              onRegisterApi: function( gridApi ){
                $scope.gridApi = gridApi;

                // interval of zero just to allow the directive to have initialized


                gridApi.core.on.columnVisibilityChanged( $scope, function( changedColumn ){
                  $scope.columnChanged = { name: changedColumn.colDef.name, visible: changedColumn.colDef.visible };
                });
              }
            };

          /*  $http.get('http://ui-grid.info/data/100.json')
              .success(function(data) {
                $scope.gridOptions.data = data;
              });*/
      loadAll();
      function loadAll(){

     

        roleService.getAllroles(config).then(function (data) {
             $scope.roleList= data.data.objects;

             for(var i=0;i<$scope.roleList.length;i++)
             {
                  $scope.roleList[i].action="";
             }
               $scope.gridOptions.data =$scope.roleList;
          });
      /*  roleService.getAllFeatures(config).then(function (data) {
            $scope.availableFeatures= data.data.objects;
            $scope.totalavailableFeatures = data.data.objects;
           
         });*/
        roleService.getAllSubFeatures (config).then(function (data) {
            $scope.availableFeatures= data.data.objects;
            $scope.totalavailableFeatures = data.data.objects;
           
         });
      
        console.log("----------"+$scope.roleList);
      }

     $scope.createrole = function () {
    	 $scope.functionality="Save";
        $scope.headername = "Create Role";
        $scope.name ="";
        $scope.description="";
        $scope.availableFeatures = [];
        $scope.includedFeatures = [];
        $scope.existingFeatures = "";
        $scope.selectedFeatures ="";
    	$scope.role={};
      //  $scope.category={};
      $scope.roleId=null;
     if ($scope.totalavailableFeatures.length > 0) {
          angular.forEach($scope.totalavailableFeatures, function(feature) {
              $scope.availableFeatures.push(feature);
          });
      }
        $rootScope.isTrascError = false;
        $scope.isView = false;
        $('div').removeClass('has-error edited').removeClass('has-error');
        $('input').removeClass('form-control edited').addClass('form-control');
        $('textarea').removeClass('form-control edited').addClass('form-control');
        $('select').removeClass('form-control edited').addClass('form-control');
        $('#role-model').modal('show');
      }
     $scope.editrole=function(value)
      	{
    	 $scope.functionality="Update";
          $scope.isView = false;
        	$scope.headername = "Edit Role";
          $scope.name ="";
          $scope.description="";
          $scope.availableFeatures = [];
          $scope.includedFeatures = [];
          $scope.existingFeatures = "";
          $scope.selectedFeatures="";
          
          $scope.role={};
      	$scope.role.roleFeatureAssociations=[{}];
          for(var i=0;i<$scope.roleList.length;i++)
          {
              if ($scope.roleList[i].roleId==value)
               {

                $scope.name=$scope.roleList[i].roleName;
                $scope.description=$scope.roleList[i].description;
                $scope.roleId=$scope.roleList[i].roleId;
              
                if($scope.roleList[i].featureList.length>0 ||$scope.roleList[i].featureList !=undefined  )
                	{
                angular.forEach($scope.roleList[i].featureList, function(feature) {
                
                    $scope.includedFeatures.push(feature);
                });
               }
              }
          }
         
         if ($scope.totalavailableFeatures.length > 0) {
              angular.forEach($scope.totalavailableFeatures, function(feature) {
                  $scope.availableFeatures.push(feature);
              });
          }
          $timeout( function(){
              if (!angular.isUndefined($scope.includedFeatures) && $scope.includedFeatures.length > 0) {
                  for (var i = 0; i < $scope.includedFeatures.length; i++) {
                      for (var j = 0; j < $scope.availableFeatures.length; j++) {
                     	 if ($scope.availableFeatures[j].featureId === $scope.includedFeatures[i].featureId) {
                              $scope.availableFeatures.splice(j, 1);
                              break;
                          }
                      }
                  }
              }
         	 }, 700 );
          $rootScope.isTrascError = false;
          $('div').removeClass('has-error edited');
          $('input').removeClass('form-control').addClass('form-control edited');
          $('textarea').removeClass('form-control').addClass('form-control edited');
          $('select').removeClass('form-control').addClass('form-control edited');
          $('#role-model').modal('show');
      				}
        $scope.viewrole=function(value)
                {
                  $scope.roleId=null;
                  $scope.name="";
                  $scope.description="";
                  $scope.headername = "View Role";
                  $scope.isView = true;
                  $scope.availableFeatures = [];
                  $scope.includedFeatures = [];
                  $scope.existingFeatures = "";
                  $scope.selectedFeatures ="";
                  $scope.role={};
              	$scope.role.roleFeatureAssociations=[{}];
                  
              	 for(var i=0;i<$scope.roleList.length;i++)
                 {
                     if ($scope.roleList[i].roleId==value)
                      {

                       $scope.name=$scope.roleList[i].roleName;
                       $scope.description=$scope.roleList[i].description;
                       $scope.roleId=$scope.roleList[i].roleId;
                     
                       if($scope.roleList[i].featureList.length>0 ||$scope.roleList[i].featureList !=undefined  )
                       	{
                       angular.forEach($scope.roleList[i].featureList, function(feature) {
                    
                           $scope.includedFeatures.push(feature);
                       });
                      }
                     }
                 }
                  
             	 if ($scope.totalavailableFeatures.length > 0) {
                      angular.forEach($scope.totalavailableFeatures, function(feature) {
                          $scope.availableFeatures.push(feature);
                      });
                  }
             	 $timeout( function(){
                  if (!angular.isUndefined($scope.includedFeatures) && $scope.includedFeatures.length > 0) {
                      for (var i = 0; i < $scope.includedFeatures.length; i++) {
                          for (var j = 0; j < $scope.availableFeatures.length; j++) {
                         	 if ($scope.availableFeatures[j].subFeatureId === $scope.includedFeatures[i].subFeatureId) {
                                  $scope.availableFeatures.splice(j, 1);
                                  break;
                              }
                          }
                      }
                  }
             	 }, 700 );
                  $rootScope.isTrascError = false;
                  $('div').removeClass('has-error edited');
                  $('input').removeClass('form-control').addClass('form-control edited');
                  $('textarea').removeClass('form-control').addClass('form-control edited');
                  $('select').removeClass('form-control').addClass('form-control edited');
                  $('#role-model').modal('show');
                      }

                      $scope.saveRole = function (rolename,roledesc) {
                    	 
                    	 
                        var role={};
                        var roleId=$scope.roleId;
                        role.roleName = rolename;
                         role.description = roledesc;
                         var selectedFeatures = $scope.selectedFeatures;
                       
                        $scope.continuesave = true;
                            if (!rolename || rolename==undefined) {

                                 $rootScope.isTrascError = true;
                                 FlashService.Error("Please Enter role Name");
                                 $scope.continuesave = false;
                             }
                            /*else if (!selectedFeatures) {
                                $rootScope.isTrascError = true;
                                FlashService.Error("Please Select at least a Feature");
                                $scope.continuesave = false;
                            }*/
                            else {
                                 $scope.continuesave = true;
                                 $rootScope.isTrascError = false;
                             }

                            if ($scope.continuesave) {
                            	
                            	role.featureList = [];
                            
                              	angular.forEach($scope.selectedFeatures, function(feature) {
        	                  		
        	                  		var selected = {
        	                  				"featureId":feature.featureId,
        	                  				"subFeatureId":feature.subFeatureId
        	                  				
        	                  		};
        	                  		
        	                  		role.featureList.push(selected);
        	                  		
        	                        //$scope.availableFeatures.push(feature);
        	                    });
                              
                                 if (!roleId) {
                                	
                                     roleService
                                             .saverole(role)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 201) {

                                                             $('#role-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 } else {
                                 
                                   role.roleId=roleId;
                                    roleService
                                             .updaterole(role)
                                             .then(
                                                     function (result) {
                                                         if (result.httpStatus == 200) {
                                                             $('#role-model').modal('hide');
                                                             loadAll();
                                                             $scope.successTextAlert = result.data.message;
                                                             $scope.showSuccessAlert = true;
                                                         } else {
                                                             $rootScope.isTrascError = true;
                                                             FlashService.Error(result.data.message);
                                                             $scope.continuesave = false;
                                                         }
                                                         $timeout(function () {
                                                             $scope.showSuccessAlert = false;
                                                         }, 5000);
                                                     });
                                 }
                             }
                      }

                      $scope.includeAllFeatures = function() {
                          if ($scope.iseditable) {
                              if ($scope.availableFeatures.length > 0) {
                                  angular.forEach($scope.availableFeatures, function(feature) {
                                      $scope.includedFeatures.push(feature);
                                  });
                                  $scope.availableFeatures = [];
                                  $scope.selectedFeatures = [];
                                  $scope.existingFeatures = [];
                                  $scope.selectedFeatures = $scope.includedFeatures;                              }
                          }
                      };
                      $scope.includeSelectedFeature = function(features) {
                    	 
                          if ($scope.iseditable) {
                              if (!angular.isUndefined(features) && features.length > 0) {
                                  for (var i = 0; i < angular.fromJson(features).length; i++) {
                                      for (var j = 0; j < $scope.availableFeatures.length; j++) {
                                          if ($scope.availableFeatures[j].subFeatureId === angular.fromJson(features[i]).subFeatureId) {

                                        	  $scope.availableFeatures.splice(j, 1);
                                              break;
                                          }
                                      }
                                    
                                      $scope.includedFeatures.push(angular.fromJson(features[i]));
                                  }
                                  $scope.selectedFeatures = $scope.includedFeatures;
                              } else {
                                  $rootScope.isTrascError = true;
                                  FlashService.Error("Please select any feature");
                                  $timeout(function() {
                                      $rootScope.isTrascError = false;
                                  }, 2000);
                                  $scope.selectedFeatures = [];
                                  $scope.existingFeatures = [];
                              }
                             
                          }
                          $scope.existingFeatures=[];
                      };
                      $scope.excludeAllFeatures = function() {
                    	
                          if ($scope.iseditable && $scope.includedFeatures.length > 0) {
                              $scope.availableFeatures = [];
                          
                              angular.forEach($scope.totalavailableFeatures, function(feature) {
                                  $scope.availableFeatures.push(feature);
                              });
                              $scope.includedFeatures = [];
                              $scope.selectedFeatures = [];
                              $scope.existingFeatures = [];
                          }
                      };
                      $scope.excludeSelectedFeatures = function(features) {
                    	 
                          if ($scope.iseditable) {
                              if (!angular.isUndefined(features) && features.length > 0) {
                                  for (var i = 0; i < angular.fromJson(features).length; i++) {
                                      for (var j = 0; j < $scope.includedFeatures.length; j++) {
                                          if ($scope.includedFeatures[j].subFeatureId === angular.fromJson(features[i]).subFeatureId) {
                                              $scope.includedFeatures.splice(j, 1);
                                              break;
                                          }
                                      }
                                   
                                      $scope.availableFeatures.push(angular.fromJson(features[i]));
                                  }
                                //  $scope.selectedFeatures = [];
                                //  $scope.existingFeatures = [];
                                
                                  $scope.selectedFeatures = $scope.includedFeatures;
                                
                                 
                              } else {
                            	
                                  $rootScope.isTrascError = true;
                                  FlashService.Error("Please select any feature");
                                  $timeout(function() {
                                      $rootScope.isTrascError = false;
                                  }, 2000);
                                  //$scope.includedFeatures = [];
                                  $scope.selectedFeatures = [];
                                  $scope.existingFeatures = [];
                              }
                              $scope.selectedFeatures =  $scope.includedFeatures;
                              //alert($scope.selectedFeatures);
                          }
                        //  $scope.selectedFeatures=[];
                      };
                      

            }]);
