var shapoorji = angular.module('myApp', [
    'ngRoute',
    'myApp.config',
    'ngCookies',
    'ngStorage',

    'ui.bootstrap',

    'angularjs-dropdown-multiselect',
    'myApp.controllers',
    'myApp.logincontroller',
    'myApp.dashboardcontroller',
    'myApp.AuthenticationService',
    'angularUtils.directives.dirPagination',
    'myApp.sidebarCtrl',
    'myApp.FlashService',
  


    'myApp.dashboardService',

    'myApp.roleService',
    'myApp.roleController',
    'myApp.userService',
    'myApp.userController',

    'myApp.featureController',
    'myApp.featureService',
    'myApp.subfeatureController',
    'myApp.subfeatureService',
   'myApp.resetPasswordController',
    'myApp.resetPasswordService',
    'ngTouch',
    'ui.grid',
    'ui.grid.exporter',
    'ui.grid.selection',
    'ui.grid.pinning',
    'ui.grid.resizeColumns',
    'ui.grid.moveColumns',
    'ui.grid.autoResize',
    'ui.grid.pagination',
    'ui.grid.moveColumns',
  'angularjs-dropdown-multiselect',
  'ngMaterial',
  'ngMessages'
])
.config(config);
shapoorji.directive(
		'validNumber',
		function() {
			return {
				require : '?ngModel',
				link : function(scope, element, attrs, ngModelCtrl) {
					if (!ngModelCtrl) {
						return;
					}
					ngModelCtrl.$parsers.push(function(val) {
						if (angular.isUndefined(val)) {
							var val = '';
						}
						var clean = val.replace(/[^-0-9\.]/g, '');
						var negativeCheck = clean.split('-');
						var decimalCheck = clean.split('.');
						if (!angular.isUndefined(negativeCheck[1])) {
							negativeCheck[1] = negativeCheck[1].slice(0,
									negativeCheck[1].length);
							clean = negativeCheck[0] + '-' + negativeCheck[1];
							if (negativeCheck[0].length > 0) {
								clean = negativeCheck[0];
							}
						}

						if (!angular.isUndefined(decimalCheck[1])) {
							decimalCheck[1] = decimalCheck[1].slice(0, 2);
							clean = decimalCheck[0] + '.' + decimalCheck[1];
						}

						if (val !== clean) {
							ngModelCtrl.$setViewValue(clean);
							ngModelCtrl.$render();
						}
						return clean;
					});

					element.bind('keypress', function(event) {
						if (event.keyCode === 32) {
							event.preventDefault();
						}
					});
				}
			};
		}).directive('validOnlynumber', function() {
	return {
		require : '?ngModel',
		link : function(scope, element, attrs, ngModelCtrl) {
			if (!ngModelCtrl) {
				return;
			}

			ngModelCtrl.$parsers.push(function(val) {
				if (angular.isUndefined(val)) {
					var val = '';
				}
				var clean = val.replace(/[^0-9]+/g, '');
				if (val !== clean) {
					ngModelCtrl.$setViewValue(clean);
					ngModelCtrl.$render();
				}
				return clean;
			});

			element.bind('keypress', function(event) {
				if (event.keyCode === 32) {
					event.preventDefault();
				}
			});
		}
	};
}).directive('noSpecialChar', function() {
	return {
		require : 'ngModel',
		restrict : 'A',
		link : function(scope, element, attrs, modelCtrl) {
			modelCtrl.$parsers.push(function(inputValue) {
				if (inputValue == null)
					return ''
				cleanInputValue = inputValue.replace(/[^a-zA-Z0-9\s]/gi, '');
				if (cleanInputValue != inputValue) {
					modelCtrl.$setViewValue(cleanInputValue);
					modelCtrl.$render();
				}
				return cleanInputValue;
			});
		}
	}
}).directive('inputRestrictor', [
                                     function() {
                                    	    return {
                                    	      restrict: 'A',
                                    	      require: 'ngModel',
                                    	      link: function(scope, element, attr, ngModelCtrl) {
                                    	        // Matches characters that aren't `0-9`, `.`, `+`, or `-`
                                    	        var pattern = /[^.0-9+-]/g;


                                    	        function fromUser(text) {
                                    	          var rep = /[+]/g;  // find + symbol (globally)
                                    	          var rem = /[-]/g;  // find - symbol (globally)
                                    	          rep.exec(text);
                                    	          rem.exec(text);

                                    	          // Find last index of each sign
                                    	          // The most recently typed characters are last
                                    	          var indexp = rep.lastIndex;
                                    	          var indexm = rem.lastIndex;

                                    	          // remove formatting, and add it back later
                                    	          text = text.replace(/[+.-]/g, '');
                                    	          if (indexp > 0 || indexm > 0) {// Are there signs?
                                    	            if (indexp > indexm){ // plus sign typed later?
                                    	              text = "+" + text;
                                    	            } else text = "-" + text;
                                    	          }

                                    	          var transformedInput = text.replace(pattern, '');
                                    	          transformedInput = transformedInput.replace(
                                    	            /([0-9]{1,2}$)/, ".$1" // make last 1 or 2 digits the decimal
                                    	          )
                                    	          ngModelCtrl.$setViewValue(transformedInput);
                                    	          ngModelCtrl.$render();
                                    	          return transformedInput;
                                    	        }
                                    	        ngModelCtrl.$parsers.push(fromUser);
                                    	      }
                                    	    };
                                    	  }
                                    	]).directive('onlyAlphabets', function() {
	return {
		require : 'ngModel',
		restrict : 'A',
		link : function(scope, element, attrs, modelCtrl) {
			modelCtrl.$parsers.push(function(inputValue) {
				if (inputValue == null)
					return ''
				cleanInputValue = inputValue.replace(/[0-9]/, '');
				if (cleanInputValue != inputValue) {
					modelCtrl.$setViewValue(cleanInputValue);
					modelCtrl.$render();
				}
				return cleanInputValue;
			});
		}
	}
}).directive('onlyNumber', function() {
	return {
		require : 'ngModel',
		restrict : 'A',
		link : function(scope, element, attrs, modelCtrl) {
			modelCtrl.$parsers.push(function(inputValue) {
				if (inputValue == null)
					return ''
				cleanInputValue = inputValue.replace(/[^0-9]/, '');
				if (cleanInputValue != inputValue) {
					modelCtrl.$setViewValue(cleanInputValue);
					modelCtrl.$render();
				}
				return cleanInputValue;
			});
		}
	}
});



function config($routeProvider, $httpProvider) {

     $routeProvider.when('/login', {title:"Login", templateUrl: 'views/login.html', controller: 'LoginCtrl', controllerAs: 'vm'});
     $routeProvider.when('/dashboard', {title:"Dashboard", templateUrl: 'views/dashboard.html', controller: 'DashboardCtrl', controllerAs: 'vm'});
     $routeProvider.when('/organization', {title:"Organization", templateUrl: 'views/organization.html', controller: 'orgcontroller', controllerAs: 'vm'});


     $routeProvider.when('/user', {templateUrl: 'views/user.html', controller: 'userController', controllerAs: 'vm'});
     $routeProvider.when('/role', {templateUrl: 'views/role.html', controller: 'RoleCtrl', controllerAs: 'vm'});
     $routeProvider.when('/feature', {templateUrl: 'views/feature.html', controller: 'featureController', controllerAs: 'vm'});
     $routeProvider.when('/subfeature', {templateUrl: 'views/subfeature.html', controller: 'subfeatureController', controllerAs: 'vm'});
     
     $routeProvider.when('/resetpassword', {templateUrl: 'views/resetpassword.html', controller: 'resetPasswordController', controllerAs: 'vm'});
    $routeProvider.when('/logout', {templateUrl: 'views/login.html', controller: 'LoginCtrl', controllerAs: 'vm'});
     $routeProvider.otherwise({redirectTo: '/login'});
     };
//shapoorji.run(['$rootScope', '$route','$location', '$cookieStore', '$http','$window',
     shapoorji.run(run);
    
function run($rootScope, $route, $location, $cookieStore, $http, $window, $sessionStorage, $localStorage) {
    // keep user logged in after page refresh
	  $sessionStorage.resetpage=false;
	 // 
	  $sessionStorage.home="http://35.184.179.5:9190/shapoorji/index.html";
	  $sessionStorage.domain="http://35.184.179.5:9190/";
	
	console.log($cookieStore.get('globals'));

	$rootScope.$on('$viewContentLoading', function(event, viewConfig)
			{
		$("#site_statistics_loading").modal('show');
			  // code that will be executed ...
			  // before the view begins loading
	});
	$rootScope.$on('$viewContentLoaded', function(event)
			{
		//$("#site_statistics_loading").modal('hide');
			  // code that will be executed ...
			  // every time this view is loaded

			 });

	$rootScope.$on('$locationChangeStart', function (event, next, current) {
        // redirect to login page if not logged in and trying to access a restricted page
	
		
		$rootScope.globals = $cookieStore.get('globals');
		var loginPage = true;
		if($location.path()!='/dashboard'){
		
    	 $localStorage.organizationId="";

		}
		else if($location.path()=='/login' || $location.path()==''){
		    loginPage = false;
		    $scope.isLogin = false;
			$sessionStorage.Login =false;
		    $rootScope.isLogin =false;
		    $location.path('/login');
		
		}
		
		var restrictedPage = $.inArray($location.path(), ['/login']) === -1;
		if($rootScope.globals && $rootScope.globals.userDTO){
		    var loggedIn = $rootScope.globals.userDTO;
		
		}/*else if (restrictedPage && !$rootScope.globals) {
	        $location.path('/login');
	    }*/

    	if (loginPage && $rootScope.globals && $rootScope.globals.userDTO) {
	       $http.defaults.headers.common['Auth_Token'] = $rootScope.globals.userDTO.token; // jshint ignore:line
	        $rootScope.features = $localStorage.features;
	        $sessionStorage.Login =true;
	        $rootScope.isLogin =true;
	    
	    }
    	else if($location.path()=='/resetpassword' ||$sessionStorage.resetpage) {
    	
    		  $sessionStorage.resetpage =true;
    	
  	      
  	      $location.path('/resetpassword');
  	    $rootScope.isResetpage=true;
    	}
    	else{
	    
	    	 $location.path('/login');
	    }
    	if($sessionStorage.afterrestpass)
    		{
    		 $location.path('/login');
    		}
    });
};
