angular.module('myApp.config', []).constant('configData',{
    "url":'http://localhost:9190/rdp-api/'
});