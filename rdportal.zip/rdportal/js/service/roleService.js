(function () {
    'use strict';

    angular
            .module('myApp.roleService', [])
            .factory('roleService', roleService);

    roleService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout', '$localStorage', '$sessionStorage','configData'];
    function roleService($http, $cookieStore, $rootScope, $timeout, $localStorage, $sessionStorage,configData) {
        var service = {};
        service.getAllroles = getAllroles;
        service.getAllFeatures = getAllFeatures;
        service.getAllSubFeatures = getAllSubFeatures;
        service.saverole = saverole;
        service.updaterole = updaterole;
        service.getRole = getRole;
        return service;


        function getAllroles(config) {
            return $http.get(configData.url+'role/list',config).then(handleSuccess, handleError('Error getting roles'));
        }

        function getAllFeatures(config) {
            return $http.get(configData.url+'feature/list',config).then(handleSuccess, handleError('Error getting features'));
        }
        function getAllSubFeatures(config) {
            return $http.get(configData.url+'subfeature/list',config).then(handleSuccess, handleError('Error getting features'));
        }

        function getRole(id) {
            return $http.get(configData.url+'role/'+id,config).then(handleSuccess, handleError('Error getting roles'));
        }

        function saverole(data) {
         return $http.post(configData.url+'role', data,config).then(handleSuccess, handleError('Error saving roles '));
        }

        function updaterole(data) {
            return $http.put(configData.url+'role', data,config).then(handleSuccess, handleError('Error saving roles '));
        }

        function handleSuccess(res) {
        	console.log("-----service"+res);
            return res.data;
        }

        function handleError(error) {
            return function () {
                return {success: false, message: error};
            };
        }


    }
})();
