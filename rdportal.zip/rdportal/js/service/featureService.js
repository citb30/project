(function () {
    'use strict';

    angular
            .module('myApp.featureService', [])
            .factory('featureService', userService);

    userService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout', '$localStorage', '$sessionStorage','configData'];
    function userService($http, $cookieStore, $rootScope, $timeout, $localStorage, $sessionStorage,configData) {
        var service = {};
        service.getAllFeature = getAllFeature;
        service.saveFeature = saveFeature;
        service.updateFeature = updateFeature;

        return service;


        function getAllFeature(config) {
            return $http.get(configData.url+'feature/list',config).then(handleSuccess, handleError('Error getting features'));
        }



        function saveFeature(data) {
         return $http.post(configData.url+'feature', data,config).then(handleSuccess, handleError('Error saving feature '));
        }

        function updateFeature(data) {
            return $http.put(configData.url+'feature', data,config).then(handleSuccess, handleError('Error saving feature '));
        }

        function handleSuccess(res) {
        	console.log("-----service"+res);
            return res.data;
        }

        function handleError(error) {
            return function () {
                return {success: false, message: error};
            };
        }


    }
})();
