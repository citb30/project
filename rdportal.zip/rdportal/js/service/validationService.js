'use strict';
myApp.service('validationService', [function(){
	this.validateEmail = function(email){
		var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;

		if(email)
			 return re.test(email);
		else
			return 0;
	};
	this.checkPhonenumber = function(phoneNumber){
		var regx = /^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/;
		
		if(phoneNumber)
			 return regx.test(phoneNumber);
		else
			return 0;
	};
	this.checkFullName = function(name){
		if(name){
			name = name.replace(/\s/g, '');
			var re = /^[a-zA-Z]+$/i;
			return re.test(name);
		}
		else
			return 0;
	};
	this.checkPwd = function(pwd,minLength, maxLength){
		if(pwd){
			if(pwd.length >= minLength && pwd.length <= maxLength)
				 return 1;
			else
				return 0;
		}else
				return 0;
	};
}]);