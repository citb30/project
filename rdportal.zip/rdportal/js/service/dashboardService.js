(function () {
    'use strict';

    angular
            .module('myApp.dashboardService', [])
            .factory('dashboardService', dashboardService);

    dashboardService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout', '$localStorage', '$sessionStorage','configData'];
    function dashboardService($http, $cookieStore, $rootScope, $timeout, $localStorage, $sessionStorage, configData) {
        var service = {};
      
        return service;
       

    
        
        function handleSuccess(res) {
        	console.log("-----service"+res);
            return res.data;
        }

        function handleError(error) {
            return function () {
                return {success: false, message: error};
            };
        }


    }
})();